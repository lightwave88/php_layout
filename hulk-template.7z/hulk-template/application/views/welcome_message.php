<# extends parent_message #>

<# block title #>CI Chinese<# /block #>