<?php

class My_Loader extends CI_Loader {

    // 记录每个 page 的 data
    protected $_ci_layout_page_stocks = array();
    // layout 的路径
    protected $_ci_layout_path = '';
    // 记录 layout 会用到的 section
    protected $_ci_layout_sectionContents = array();
    protected $_ci_layout_pageID = 0;
    // 正在操作 page 的 id
    protected $_ci_layout_operate_page_id;
    // 记录每个 page _ci_load() 引用的参数
    protected $_ci_load_params;

    //--------------------------------------------------------------------------

    /**
     * loader->view(), loader->file() 会呼叫
     * 
     * @param type $_ci_data
     */
    protected function _ci_load($_ci_data) {

        printf('<p>MY_loader</p>');

        // 整理引数
        $params = array(
            '_ci_view' => false,
            '_ci_vars' => false,
            '_ci_path' => false,
            '_ci_return' => false
        );

        foreach ($params as $key => $val) {
            if (isset($_ci_data[$key])) {
                $params[$key] = $_ci_data[$key];
            }
        }
        //-----------------------

        if (is_string($params['_ci_path']) && $params['_ci_path'] !== '') {
            // loader->file()

            return $this->_ci_load_file($params);
        } else {
            // loader->view()
            // 记录本页取得的参数
            $this->_ci_load_params = $params;
            //-----------------------
            // 为每个 page 付一个 id 供辨认
            // 本页的 id
            $page_id = $this->_ci_layout_pageID++;

            // 记录操作页面的 id
            $this->_ci_layout_operate_page_id = $page_id;
            /*
             * 每个 page 的资料
             * 预设 view 是只有单一页面
             * 但 layout 却会有至少一个子页面以上(子页面继承的关系)  
             */
            $page_data = array(
                'id' => $page_id,
                'extend' => null,
                'sections' => array(),
                'nesting' => array()
            );

            $this->_ci_layout_pages[$page_id] = &$page_data;
            //-----------------------
            $_ci_ext = pathinfo($params['_ci_view'], PATHINFO_EXTENSION);
            $_ci_file = ($_ci_ext === '') ? ($params['_ci_view'] . '.php') : $params['_ci_view'];

            foreach ($this->_ci_view_paths as $_ci_view_file => $cascade) {
                $file = $_ci_view_file . $_ci_file;

                printf('<p>file=%s</p>', $file);

                if (file_exists($file)) {
                    $params['_ci_path'] = $file;
                    break;
                }
                if (!$cascade) {
                    break;
                }
            }
        }
        if (empty($params['_ci_path'])) {
            show_error('Unable to load the requested file: ' . $_ci_file);
        }
        //-----------------------

        $_ci_CI = & get_instance();

        if ($this->_ci_layout_operate_page_id == 0) {
            /*
             * 把所有 controller 的属性拷贝到 loader
             * 将 loader 作为 view 的 context
             */
            foreach (get_object_vars($_ci_CI) as $_ci_key => $_ci_var) {
                if (!isset($this->$_ci_key)) {
                    $this->$_ci_key = & $_ci_CI->$_ci_key;
                }
            }
        }

        /*
         * Extract and cache variables
         *
         * You can either set variables using the dedicated $this->load->vars()
         * function or via the second parameter of this function. We'll merge
         * the two types and cache them so that views that are embedded within
         * other views can have access to these variables.
         */
        if (empty($params['_ci_vars'])) {
            $this->_ci_cached_vars = array_merge($this->_ci_cached_vars, $params['_ci_vars']);
        }
        extract($this->_ci_cached_vars);

        ob_start();

        printf('(%s)include(%s)', $this->_ci_layout_operate_page_id,$params['_ci_path']);
        
        include($params['_ci_path']);
        //-----------------------
        /*
         * 若文本有 extend() 命令
         * 会被暂时中断，进入递回
         */
        //-----------------------
        if (count($page_data['sections']) > 0 || $page_data['extend']):
            // 是子模板

            if ($this->_ci_layout_operate_page_id == 0) {
                // 全部的 page 都跑完了

                printf('<p>全部的 page 都跑完了</p>');

                if (empty($this->_ci_layout_path)) {
                    show_error('no assign layout');
                }

                $this->_ci_load_params['_ci_view'] = $this->_ci_layout_path;

                // 整理 section 收集来的资讯
                $this->_ci_getRenderSection();
                // load layout
                // 进入一般 view 模式
                return $this->_ci_load($this->_ci_load_params);
            }
            return;
        else:
            // 一般的 view

            if ($params['_ci_return'] === TRUE) {
                $buffer = ob_get_contents();
                @ob_end_clean();
                return $buffer;
            } else {

                /*
                 * Flush the buffer... or buff the flusher?
                 *
                 * In order to permit views to be nested within
                 * other views, we need to flush the content back out whenever
                 * we are beyond the first level of output buffering so that
                 * it can be seen and included properly by the first included
                 * template and any subsequent ones. Oy!
                 */
                if (ob_get_level() > $this->_ci_ob_level + 1) {
                    ob_end_flush();
                } else {
                    $_ci_CI->output->append_output(ob_get_contents());
                    @ob_end_clean();
                }

                return $this;
            }
        endif;
    }

    //--------------------------------------------------------------------------
    protected function _ci_load_file($params) {
        $_ci_x = explode('/', $_ci_path);
        $_ci_file = end($_ci_x);

        if (!file_exists($params['_ci_path'])) {
            show_error('Unable to load the requested file: ' . $_ci_file);
        }
    }

    //--------------------------------------------------------------------------

    /**
     * 指定 layout 
     * 
     * @param type $file_path
     */
    public function layout($file_path) {
        $_ci_path = null;
        $_ci_ext = pathinfo($file_path, PATHINFO_EXTENSION);
        $_ci_file = ($_ci_ext === '') ? $file_path . '.php' : $file_path;

        foreach ($this->_ci_view_paths as $_ci_view_file => $cascade) {
            $file = $_ci_view_file . $_ci_file;
            if (file_exists($file)) {
                $_ci_path = $file;
                break;
            }

            if (!$cascade) {
                break;
            }
        }

        if (empty($_ci_path)) {
            show_error('Unable to load the requested layout: ' . $_ci_file);
        } else {
            // 取得 layout.path
            $this->_ci_layout_path = $_ci_file;
        }
    }

    //--------------------------------------------------------------------------

    /**
     * 页面继承
     * 
     * @param type $file_path
     * @throws Exception
     */
    public function extend($file_path) {

        $_ci_data = $this->_ci_load_params;

        $page_id = $this->_ci_layout_operate_page_id;
        $page_data = &$this->_ci_get_pageData($page_id);

        if (empty($page_data['extend'])) {
            // 旗标
            $page_data['extend'] = $file_path;
            $_ci_data['_ci_view'] = $file_path;
        } else {
			// 重复 extend
            show_error("double extend");            
        }

        /*
         * 在这边故意练习采用递回先从(parent->child)的方向
         * 分析起
         * 不用递回也可分析页面的方向变为(child->parent)
         * 减少难度
         */
        $this->_ci_load($_ci_data);

        // 本页面回归为操作页面
        $this->_ci_layout_operate_page_id = $page_id;
    }

    //--------------------------------------------------------------------------
    public function element() {
        
    }

    //--------------------------------------------------------------------------

    protected function renderSection($section_name) {
        printf('<p>renderSection(%s)</p>', $section_name);
        // var_dump($this->_ci_layout_sectionContents);
        if (!isset($this->_ci_layout_sectionContents[$section_name])) {
            show_error("layout section({$section_name}) no exists");
        }
        echo $this->_ci_layout_sectionContents[$section_name];
    }

    //--------------------------------------------------------------------------
    public function section($secttion_name) {

        $page_data = &$this->_ci_get_pageData($this->_ci_layout_operate_page_id);
        $sections = &$page_data['sections'];
        // 旗标
        $nesting = &$page_data['nesting'];

        ob_start();

        if (isset($sections[$secttion_name])) {
            // 重复使用 section
            show_error("section({$secttion_name}) has declear");
        }
        // 用于检测套嵌是否正确
        array_push($nesting, $secttion_name);
    }

    //--------------------------------------------------------------------------
    public function endSection($s_name) {
        $page_data = &$this->_ci_get_pageData($this->_ci_layout_operate_page_id);
        $sections = &$page_data['sections'];
        $nesting = &$page_data['nesting'];

        $content = ob_get_clean();

        // 用于检测套嵌是否正确
        $section_name = array_pop($nesting);
        if (strcmp($section_name, $s_name) != 0) {
            show_error("section start(${$section_name}) not match end({$s_nsme})");
        }
        // 记录内容
        $sections[$section_name] = $content;
        echo $content;
    }

    //--------------------------------------------------------------------------
    // 取得当前页面的 data
    protected function &_ci_get_pageData($page_id) {
        return $this->_ci_layout_pages[$page_id];
    }

    //--------------------------------------------------------------------------
    protected function _ci_getRenderSection() {

        // var_dump($this->_ci_layout_pages);

        $sectionContents = &$this->_ci_layout_sectionContents;

        foreach ($this->_ci_layout_pages as $page):
            /*
             * 从child 方向往 parent 推
             * 抽取每个 page 的 sections
             */

            $sections = $page['sections'];

            foreach ($sections as $section => $content) {

                if (isset($sectionContents[$section])) {
                    // 已经被 override
                    continue;
                } else {
                    $sectionContents[$section] = $content;
                }
            }
        endforeach;

        var_dump($sectionContents);
    }

}
