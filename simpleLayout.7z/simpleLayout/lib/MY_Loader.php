<?php

class My_Loader extends CI_Loader {

    /**
     * layoutFile 的档名前缀
     * 可在 config.php $config['layout_file_prefix']
     * 覆盖设定
     */
    const LAYOUT_FILE_PREFIX = 'layout_';

    /**
     * layout 使用
     * 记录每个 page 的 data
     * 
     * @var type 
     */
    protected $_ci_layout_page_stocks = array();

    /**
     * layout 使用
     * layout 的路径
     * 
     * @var type 
     */
    protected $_ci_layout_path = '';

    /**
     * layout 使用
     * 记录 layout 会用到的 section
     * 
     * @var type 
     */
    protected $_ci_layout_sectionContents = array();

    /**
     * 产生页面编号
     * 
     * @var type 
     */
    protected $_ci_layout_pageID = 0;

    /**
     * 记录当前正在操作 page 的 id
     * 
     * @var type 
     */
    protected $_ci_layout_operate_page_id;

    //--------------------------------------------------------------------------

    /**
     * loader->view(), loader->file() 会呼叫
     * 
     * @param type $_ci_data
     */
    protected function _ci_load($_ci_data) {

        printf('<p>MY_loader</p>');

        // 整理引数
        $params = array(
            '_ci_view' => false,
            '_ci_vars' => false,
            '_ci_path' => false,
            '_ci_return' => false,
            '_ci_layout' => false
        );

        foreach ($params as $key => $val) {
            if (isset($_ci_data[$key])) {
                $params[$key] = $_ci_data[$key];
            }
        }
        //-----------------------

        if (is_string($params['_ci_path']) && $params['_ci_path'] !== '') {
            /*
             * loader->file()
             */
            return $this->_ci_load_file($params);
        } else {
            /*
             * loader->view()
             */

            // 
            // 为每个 page 付一个 id 供辨认
            $page_id = $this->_ci_layout_pageID++;

            // 记录操作页面的 id
            $this->_ci_layout_operate_page_id = $page_id;
            /*
             * 每个 page 的资料
             * 预设 view 是只有单一页面
             * 但 layout 却会有至少一个子页面以上(子页面继承的关系)
             * 
             * extend: 记录使用者设定的 extend 页面
             * sections: 记录使用的 section
             * nesting: 记录 section 的套嵌，检测用
             */
            $page_data = array(
                'id' => $page_id,
                'extend' => null,
                'sections' => array(),
                'nesting' => array()
            );

            $this->_ci_layout_page_stocks[$page_id] = &$page_data;
            //-----------------------
            // load_file 的程序

            $_ci_file;
            $view_file;

            $_ci_ext = pathinfo($params['_ci_view'], PATHINFO_EXTENSION);
            $_ci_file = ($_ci_ext === '') ? ($params['_ci_view'] . '.php') : $params['_ci_view'];

            if ($params['_ci_layout'] === true) {
                /*
                 * 若本页是 layout
                 * 检测是否有使用档名前缀
                 */
                $layout_file_prefix = config_item('layout_file_prefix');
                if (is_null($layout_file_prefix)) {
                    $layout_file_prefix = self::LAYOUT_FILE_PREFIX;
                }
                $_ci_file = $layout_file_prefix . $_ci_file;
            }

            foreach ($this->_ci_view_paths as $_ci_view_file => $cascade) {
                $file = $_ci_view_file . $_ci_file;

                printf('<p>file=%s</p>', $file);

                if (file_exists($file)) {
                    $view_file = $file;
                    break;
                }
                if (!$cascade) {
                    break;
                }
            }
        }
        if (empty($view_file)) {
            show_error('Unable to load the requested file: ' . $_ci_file);
        }
        //-----------------------
        $_ci_CI = & get_instance();

        /*
         * 把当前的 loader 当做 view 的 context
         * 把所有 controller 的属性拷贝到 loader 上
         */
        foreach (get_object_vars($_ci_CI) as $_ci_key => $_ci_var) {
            if (!isset($this->$_ci_key)) {
                $this->$_ci_key = & $_ci_CI->$_ci_key;
            }
        }

        /*
         * Extract and cache variables
         *
         * You can either set variables using the dedicated $this->load->vars()
         * function or via the second parameter of this function. We'll merge
         * the two types and cache them so that views that are embedded within
         * other views can have access to these variables.
         */
        if (empty($params['_ci_vars'])) {
            $this->_ci_cached_vars = array_merge($this->_ci_cached_vars, $params['_ci_vars']);
        }
        extract($this->_ci_cached_vars);

        ob_start();

        printf('page(%s)include(%s)', $page_id, $view_file);


        if (!is_php('5.4') && !ini_get('short_open_tag') && config_item('rewrite_short_tags') === TRUE) {
            echo eval('?>' . preg_replace('/;*\s*\?>/', '; ?>', str_replace('<?=', '<?php echo ', file_get_contents($view_file))));
        } else {
            include($view_file); // include() vs include_once() allows for multiple views with the same name
        }
        //-----------------------
        if (count($page_data['sections']) > 0):
            // 本阶段是子模板

            if (!empty($page_data['extend'])) {
                /*
                 * 若页面有继承其他页面
                 * 遞迴進入父頁面，獲取資訊
                 */
                $params['_ci_view'] = $page_data['extend'];
                $this->_ci_load($params);
            }


            if ($page_id == 0) {
                // 全部的继承 page 都跑完了

                printf('<p>全部的 page 都跑完了</p>');

                if (empty($this->_ci_layout_path)) {
                    // 若没有指定 layouy
                    show_error('no assign layout');
                }

                /*
                 * load layout
                 */
                $params['_ci_view'] = $this->_ci_layout_path;
                $params['_ci_layout'] = true;

                // 整理 section 收集来的资讯
                $this->_ci_getRenderSection();

                // 进入一般 view 模式
                return $this->_ci_load($params);
            } else {
                return;
            }
        else:
            // 一般的 view or layout

            if ($params['_ci_return'] === TRUE) {
                $buffer = ob_get_contents();
                @ob_end_clean();
                return $buffer;
            } else {

                /*
                 * Flush the buffer... or buff the flusher?
                 *
                 * In order to permit views to be nested within
                 * other views, we need to flush the content back out whenever
                 * we are beyond the first level of output buffering so that
                 * it can be seen and included properly by the first included
                 * template and any subsequent ones. Oy!
                 */
                if (ob_get_level() > $this->_ci_ob_level + 1) {
                    /*
                     * 在 view 里面套嵌使用 $this->loader->view(f$ile, false)
                     * 就会进入这里
                     * 若呼叫 $_ci_CI->output->append_output(ob_get_contents());
                     * 会发生内容次序错误
                     */
                    ob_end_flush();
                } else {
                    $_ci_CI->output->append_output(ob_get_contents());
                    @ob_end_clean();
                }

                return $this;
            }
        endif;
    }

    //--------------------------------------------------------------------------
    protected function _ci_load_file($params) {
        $_ci_x = explode('/', $_ci_path);
        $_ci_file = end($_ci_x);

        if (!file_exists($params['_ci_path'])) {
            show_error('Unable to load the requested file: ' . $_ci_file);
        }
    }

    //--------------------------------------------------------------------------

    /**
     * 指定 layout 
     * 
     * @param type $file_path
     */
    public function layout($file_path) {
        if (count($this->_ci_layout_page_stocks) > 0) {
            throw new Exception("进入 renfer 阶段，已不能再指派 layout");
        }
        $this->_ci_layout_path = $file_path;
    }

    //--------------------------------------------------------------------------

    /**
     * 页面继承
     * 
     * @param type $file_path
     * @throws Exception
     */
    public function extend($file_path) {
        $page_id = $this->_ci_layout_operate_page_id;
        $page_data = &$this->_ci_get_pageData($page_id);

        if (empty($page_data['extend'])) {
            // 旗标
            $page_data['extend'] = $file_path;
        } else {
            // 重复 extend
            show_error("extend 只能使用一次");
        }
    }

    //--------------------------------------------------------------------------
    public function element() {
        
    }

    //--------------------------------------------------------------------------

    /**
     * layout api
     * 
     * @param type $section_name
     */
    protected function renderSection($section_name) {
        printf('<p>renderSection(%s)</p>', $section_name);
        // var_dump($this->_ci_layout_sectionContents);
        if (!isset($this->_ci_layout_sectionContents[$section_name])) {
            show_error("layout section({$section_name}) no exists");
        }
        echo $this->_ci_layout_sectionContents[$section_name];
    }

    //--------------------------------------------------------------------------

    /**
     * API
     * 
     * @param type $secttion_name
     */
    public function section($secttion_name) {

        $page_data = &$this->_ci_get_pageData($this->_ci_layout_operate_page_id);
        $sections = &$page_data['sections'];
        // 旗标
        $nesting = &$page_data['nesting'];

        ob_start();

        if (isset($sections[$secttion_name])) {
            // 重复使用 section
            show_error("section({$secttion_name}) has declear");
        }
        // 用于检测 section 套嵌是否正确
        array_push($nesting, $secttion_name);
    }

    //--------------------------------------------------------------------------

    /**
     * API
     * 
     * @param type $s_name
     */
    public function endSection($s_name) {
        $page_data = &$this->_ci_get_pageData($this->_ci_layout_operate_page_id);
        $sections = &$page_data['sections'];
        $nesting = &$page_data['nesting'];

        $content = ob_get_clean();

        // 用于检测套嵌是否正确
        $section_name = array_pop($nesting);
        if (strcmp($section_name, $s_name) != 0) {
            show_error("section start(${$section_name}) not match end({$s_nsme})");
        }
        // 记录内容
        $sections[$section_name] = $content;

        if (count($nesting) > 0) {
            /*
             * <最大的修改处>
             * 简化原有步掫
             * 
             * 若是套嵌 section
             * 直接 render
             */
            echo $content;
        }
    }

    //--------------------------------------------------------------------------
    // 取得当前页面的 data
    protected function &_ci_get_pageData($page_id) {
        return $this->_ci_layout_page_stocks[$page_id];
    }

    //--------------------------------------------------------------------------
    protected function _ci_getRenderSection() {

        // var_dump($this->_ci_layout_pages);

        $sectionContents = &$this->_ci_layout_sectionContents;

        foreach ($this->_ci_layout_page_stocks as $page):
            /*
             * 从child 方向往 parent 推
             * 抽取每个 page 的 sections
             */

            $sections = $page['sections'];

            foreach ($sections as $section => $content) {

                if (isset($sectionContents[$section])) {
                    // 已经被 override
                    continue;
                } else {
                    $sectionContents[$section] = $content;
                }
            }
        endforeach;

        var_dump($sectionContents);
    }

}
