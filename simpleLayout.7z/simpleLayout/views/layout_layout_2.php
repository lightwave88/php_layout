<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>layout_2</h1>
        <div>
            <h4>a content</h4>
            <?php $this->renderSection("a"); ?>
        </div>
        <hr>
        <div>
            <h4>b content</h4>
            <?php $this->renderSection("b"); ?>
        </div>
    </body>
</html>
