<?php

$this->section('a');
?>
<p>view_1......a</p>
<?php

$this->endSection('a');
?>

<?php

$this->section('c');
?>
<p>view_1......c</p>
<?php

$this->endSection('c');
?>


