<?php

$this->extend('view_1');

$this->section('a');
?>
<p>view_2......a</p>
<?php

$this->endSection('a');


$this->section('b');
?>
<p>view_2......b</p>
<?php

$this->endSection('b');
?>
