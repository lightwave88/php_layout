<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$this->section('a');
?>
<p> i am a</p>
<p> i am a</p>
<p> i am a</p>
<?php

$this->section('b');
?>
<p> i am b</p>
<p> i am b</p>
<p> i am b</p>
<?php

$this->endSection('b');
?>
<p> i am a</p>
<p> i am a</p>
<p> i am a</p>
<?php

$this->endSection('a');
?>