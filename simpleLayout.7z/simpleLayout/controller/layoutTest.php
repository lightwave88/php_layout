<?php

class T1 extends CI_Controller {

    public function index() {
        printf('<p>T1.index()...</p>');

        $this->load->layout('layout_1');
        $this->load->view('view_2');
    }

    public function t2(){
        printf('<p>T1.t2()...</p>');

        $this->load->layout('layout_2');
        $this->load->view('view_3');
    }
}
